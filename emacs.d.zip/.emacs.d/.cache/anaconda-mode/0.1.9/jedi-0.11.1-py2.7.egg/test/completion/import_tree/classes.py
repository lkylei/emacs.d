blub = 1

class Config2():
    pass


class BaseClass():
    mode = Config2()
    if isinstance(whaat, int):
        mode2 = whaat
